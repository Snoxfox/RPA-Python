import React, { useState } from 'react';
import { fetchRegions } from '../services/api';

function CountryInput({ setCountry, setRegions }) {
  const [input, setInput] = useState('');

  const handleSubmit = async () => {
    const response = await fetchRegions(input);
    if (response.regions) {
      setCountry(input);
      setRegions(response.regions);
    }
  };

  return (
    <div>
      <input value={input} onChange={(e) => setInput(e.target.value)} placeholder="Enter a country" />
      <button onClick={handleSubmit}>Submit</button>
    </div>
  );
}

export default CountryInput;