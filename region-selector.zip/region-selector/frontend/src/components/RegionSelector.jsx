import React from 'react';

function RegionSelector({ regions, selected, setSelected }) {
  const toggleRegion = (region) => {
    setSelected(prev =>
      prev.includes(region) ? prev.filter(r => r !== region) : [...prev, region]
    );
  };

  return (
    <div>
      <h3>Select Regions:</h3>
      {regions.map(region => (
        <div key={region}>
          <input
            type="checkbox"
            value={region}
            checked={selected.includes(region)}
            onChange={() => toggleRegion(region)}
          />
          {region}
        </div>
      ))}
    </div>
  );
}

export default RegionSelector;