export const fetchRegions = async (country) => {
  const res = await fetch('http://localhost:5000/api/regions', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ country }),
  });
  return res.json();
};