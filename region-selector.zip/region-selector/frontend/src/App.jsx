import React, { useState } from 'react';
import CountryInput from './components/CountryInput';
import RegionSelector from './components/RegionSelector';

function App() {
  const [country, setCountry] = useState('');
  const [regions, setRegions] = useState([]);
  const [selected, setSelected] = useState([]);

  return (
    <div>
      <h1>Region Selector</h1>
      <CountryInput setCountry={setCountry} setRegions={setRegions} />
      {regions.length > 0 && (
        <RegionSelector regions={regions} selected={selected} setSelected={setSelected} />
      )}
    </div>
  );
}

export default App;