import pycountry

def get_regions_by_country(country_name):
    if country_name.lower() == "united states":
        return ["California", "Texas", "New York", "Florida", "Illinois"]
    return ["Region 1", "Region 2", "Region 3"]