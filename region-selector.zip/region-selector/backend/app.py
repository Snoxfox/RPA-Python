from flask import Flask, request, jsonify
from flask_cors import CORS
from services.regions import get_regions_by_country

app = Flask(__name__)
CORS(app)

@app.route('/api/regions', methods=['POST'])
def regions():
    data = request.json
    country = data.get('country')
    if not country:
        return jsonify({'error': 'Country is required'}), 400

    regions = get_regions_by_country(country)
    return jsonify({'regions': regions})

if __name__ == '__main__':
    app.run(debug=True)